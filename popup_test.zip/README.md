
# 下载依赖包 npm install 
# 打包 npm start  打包后出现build文件夹表示打包成功
# 本地服务器  npm run server  (开启服务器前需修改config.json 文件中的ip 地址 --host 192.168.30.213 改成自己电脑的ip)

