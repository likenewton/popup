
import Popup from './popup';

module.exports = {
	// === 公共组件
    Popup, // 弹框
}